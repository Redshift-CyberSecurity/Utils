The examples here are from real events, the NT Hashes here are crackable and are here to show as an example of what the script collects.

Information including the encrypted file have been slightly modified for this example.